import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/special-places',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SpecialPlaceController::index
 * @see app/Http/Controllers/SpecialPlaceController.php:18
 * @route '/special-places'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/special-places/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SpecialPlaceController::create
 * @see app/Http/Controllers/SpecialPlaceController.php:72
 * @route '/special-places/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\SpecialPlaceController::store
 * @see app/Http/Controllers/SpecialPlaceController.php:83
 * @route '/special-places'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/special-places',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SpecialPlaceController::store
 * @see app/Http/Controllers/SpecialPlaceController.php:83
 * @route '/special-places'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpecialPlaceController::store
 * @see app/Http/Controllers/SpecialPlaceController.php:83
 * @route '/special-places'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SpecialPlaceController::store
 * @see app/Http/Controllers/SpecialPlaceController.php:83
 * @route '/special-places'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SpecialPlaceController::store
 * @see app/Http/Controllers/SpecialPlaceController.php:83
 * @route '/special-places'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
export const edit = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/special-places/{special_place}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
edit.url = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { special_place: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    special_place: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        special_place: args.special_place,
                }

    return edit.definition.url
            .replace('{special_place}', parsedArgs.special_place.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
edit.get = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
edit.head = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
    const editForm = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
        editForm.get = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SpecialPlaceController::edit
 * @see app/Http/Controllers/SpecialPlaceController.php:107
 * @route '/special-places/{special_place}/edit'
 */
        editForm.head = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
export const update = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/special-places/{special_place}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
update.url = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { special_place: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    special_place: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        special_place: args.special_place,
                }

    return update.definition.url
            .replace('{special_place}', parsedArgs.special_place.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
update.put = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
update.patch = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
    const updateForm = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
        updateForm.put = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\SpecialPlaceController::update
 * @see app/Http/Controllers/SpecialPlaceController.php:121
 * @route '/special-places/{special_place}'
 */
        updateForm.patch = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SpecialPlaceController::destroy
 * @see app/Http/Controllers/SpecialPlaceController.php:145
 * @route '/special-places/{special_place}'
 */
export const destroy = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/special-places/{special_place}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SpecialPlaceController::destroy
 * @see app/Http/Controllers/SpecialPlaceController.php:145
 * @route '/special-places/{special_place}'
 */
destroy.url = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { special_place: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    special_place: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        special_place: args.special_place,
                }

    return destroy.definition.url
            .replace('{special_place}', parsedArgs.special_place.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SpecialPlaceController::destroy
 * @see app/Http/Controllers/SpecialPlaceController.php:145
 * @route '/special-places/{special_place}'
 */
destroy.delete = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SpecialPlaceController::destroy
 * @see app/Http/Controllers/SpecialPlaceController.php:145
 * @route '/special-places/{special_place}'
 */
    const destroyForm = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SpecialPlaceController::destroy
 * @see app/Http/Controllers/SpecialPlaceController.php:145
 * @route '/special-places/{special_place}'
 */
        destroyForm.delete = (args: { special_place: string | number } | [special_place: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SpecialPlaceController = { index, create, store, edit, update, destroy }

export default SpecialPlaceController