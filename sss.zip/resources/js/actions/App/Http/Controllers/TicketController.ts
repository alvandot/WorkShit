import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/tickets/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::exportMethod
 * @see app/Http/Controllers/TicketController.php:173
 * @route '/tickets/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
export const detail = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detail.url(args, options),
    method: 'get',
})

detail.definition = {
    methods: ["get","head"],
    url: '/tickets/{ticket}/detail',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
detail.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return detail.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
detail.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
detail.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
    const detailForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: detail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
        detailForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: detail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::detail
 * @see app/Http/Controllers/TicketController.php:109
 * @route '/tickets/{ticket}/detail'
 */
        detailForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: detail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    detail.form = detailForm
/**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
export const timeline = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeline.url(args, options),
    method: 'get',
})

timeline.definition = {
    methods: ["get","head"],
    url: '/tickets/{ticket}/timeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
timeline.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return timeline.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
timeline.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: timeline.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
timeline.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: timeline.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
    const timelineForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: timeline.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
        timelineForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeline.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::timeline
 * @see app/Http/Controllers/TicketController.php:181
 * @route '/tickets/{ticket}/timeline'
 */
        timelineForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: timeline.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    timeline.form = timelineForm
/**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
export const downloadFile = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadFile.url(args, options),
    method: 'get',
})

downloadFile.definition = {
    methods: ["get","head"],
    url: '/tickets/{ticket}/download/{fileType}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
downloadFile.url = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    fileType: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                fileType: args.fileType,
                }

    return downloadFile.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{fileType}', parsedArgs.fileType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
downloadFile.get = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadFile.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
downloadFile.head = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadFile.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
    const downloadFileForm = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadFile.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
        downloadFileForm.get = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadFile.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::downloadFile
 * @see app/Http/Controllers/TicketController.php:362
 * @route '/tickets/{ticket}/download/{fileType}'
 */
        downloadFileForm.head = (args: { ticket: number | { id: number }, fileType: string | number } | [ticket: number | { id: number }, fileType: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadFile.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadFile.form = downloadFileForm
/**
* @see \App\Http\Controllers\TicketController::addActivity
 * @see app/Http/Controllers/TicketController.php:204
 * @route '/tickets/{ticket}/activities'
 */
export const addActivity = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addActivity.url(args, options),
    method: 'post',
})

addActivity.definition = {
    methods: ["post"],
    url: '/tickets/{ticket}/activities',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::addActivity
 * @see app/Http/Controllers/TicketController.php:204
 * @route '/tickets/{ticket}/activities'
 */
addActivity.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return addActivity.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::addActivity
 * @see app/Http/Controllers/TicketController.php:204
 * @route '/tickets/{ticket}/activities'
 */
addActivity.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addActivity.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::addActivity
 * @see app/Http/Controllers/TicketController.php:204
 * @route '/tickets/{ticket}/activities'
 */
    const addActivityForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addActivity.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::addActivity
 * @see app/Http/Controllers/TicketController.php:204
 * @route '/tickets/{ticket}/activities'
 */
        addActivityForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addActivity.url(args, options),
            method: 'post',
        })
    
    addActivity.form = addActivityForm
/**
* @see \App\Http\Controllers\TicketController::complete
 * @see app/Http/Controllers/TicketController.php:244
 * @route '/tickets/{ticket}/complete'
 */
export const complete = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/tickets/{ticket}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::complete
 * @see app/Http/Controllers/TicketController.php:244
 * @route '/tickets/{ticket}/complete'
 */
complete.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return complete.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::complete
 * @see app/Http/Controllers/TicketController.php:244
 * @route '/tickets/{ticket}/complete'
 */
complete.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::complete
 * @see app/Http/Controllers/TicketController.php:244
 * @route '/tickets/{ticket}/complete'
 */
    const completeForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::complete
 * @see app/Http/Controllers/TicketController.php:244
 * @route '/tickets/{ticket}/complete'
 */
        completeForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\TicketController::revisit
 * @see app/Http/Controllers/TicketController.php:313
 * @route '/tickets/{ticket}/revisit'
 */
export const revisit = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revisit.url(args, options),
    method: 'post',
})

revisit.definition = {
    methods: ["post"],
    url: '/tickets/{ticket}/revisit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::revisit
 * @see app/Http/Controllers/TicketController.php:313
 * @route '/tickets/{ticket}/revisit'
 */
revisit.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return revisit.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::revisit
 * @see app/Http/Controllers/TicketController.php:313
 * @route '/tickets/{ticket}/revisit'
 */
revisit.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revisit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::revisit
 * @see app/Http/Controllers/TicketController.php:313
 * @route '/tickets/{ticket}/revisit'
 */
    const revisitForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: revisit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::revisit
 * @see app/Http/Controllers/TicketController.php:313
 * @route '/tickets/{ticket}/revisit'
 */
        revisitForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: revisit.url(args, options),
            method: 'post',
        })
    
    revisit.form = revisitForm
/**
* @see \App\Http\Controllers\TicketController::scheduleVisit
 * @see app/Http/Controllers/TicketController.php:393
 * @route '/tickets/{ticket}/schedule-visit/{visitNumber}'
 */
export const scheduleVisit = (args: { ticket: number | { id: number }, visitNumber: string | number } | [ticket: number | { id: number }, visitNumber: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scheduleVisit.url(args, options),
    method: 'post',
})

scheduleVisit.definition = {
    methods: ["post"],
    url: '/tickets/{ticket}/schedule-visit/{visitNumber}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::scheduleVisit
 * @see app/Http/Controllers/TicketController.php:393
 * @route '/tickets/{ticket}/schedule-visit/{visitNumber}'
 */
scheduleVisit.url = (args: { ticket: number | { id: number }, visitNumber: string | number } | [ticket: number | { id: number }, visitNumber: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                    visitNumber: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                                visitNumber: args.visitNumber,
                }

    return scheduleVisit.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace('{visitNumber}', parsedArgs.visitNumber.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::scheduleVisit
 * @see app/Http/Controllers/TicketController.php:393
 * @route '/tickets/{ticket}/schedule-visit/{visitNumber}'
 */
scheduleVisit.post = (args: { ticket: number | { id: number }, visitNumber: string | number } | [ticket: number | { id: number }, visitNumber: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scheduleVisit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::scheduleVisit
 * @see app/Http/Controllers/TicketController.php:393
 * @route '/tickets/{ticket}/schedule-visit/{visitNumber}'
 */
    const scheduleVisitForm = (args: { ticket: number | { id: number }, visitNumber: string | number } | [ticket: number | { id: number }, visitNumber: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: scheduleVisit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::scheduleVisit
 * @see app/Http/Controllers/TicketController.php:393
 * @route '/tickets/{ticket}/schedule-visit/{visitNumber}'
 */
        scheduleVisitForm.post = (args: { ticket: number | { id: number }, visitNumber: string | number } | [ticket: number | { id: number }, visitNumber: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: scheduleVisit.url(args, options),
            method: 'post',
        })
    
    scheduleVisit.form = scheduleVisitForm
/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:17
 * @route '/tickets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/tickets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:57
 * @route '/tickets/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:67
 * @route '/tickets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/tickets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:67
 * @route '/tickets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:67
 * @route '/tickets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:67
 * @route '/tickets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:67
 * @route '/tickets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
export const show = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
show.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return show.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
show.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
show.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
    const showForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
        showForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:95
 * @route '/tickets/{ticket}'
 */
        showForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
export const edit = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/tickets/{ticket}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
edit.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return edit.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
edit.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
edit.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
    const editForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
        editForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:126
 * @route '/tickets/{ticket}/edit'
 */
        editForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
const updatec01838f323cf89cfdef87042932aca44 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatec01838f323cf89cfdef87042932aca44.url(args, options),
    method: 'put',
})

updatec01838f323cf89cfdef87042932aca44.definition = {
    methods: ["put"],
    url: '/tickets/{ticket}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
updatec01838f323cf89cfdef87042932aca44.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return updatec01838f323cf89cfdef87042932aca44.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
updatec01838f323cf89cfdef87042932aca44.put = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatec01838f323cf89cfdef87042932aca44.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
    const updatec01838f323cf89cfdef87042932aca44Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatec01838f323cf89cfdef87042932aca44.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
        updatec01838f323cf89cfdef87042932aca44Form.put = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatec01838f323cf89cfdef87042932aca44.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatec01838f323cf89cfdef87042932aca44.form = updatec01838f323cf89cfdef87042932aca44Form
    /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
const updatec01838f323cf89cfdef87042932aca44 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatec01838f323cf89cfdef87042932aca44.url(args, options),
    method: 'patch',
})

updatec01838f323cf89cfdef87042932aca44.definition = {
    methods: ["patch"],
    url: '/tickets/{ticket}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
updatec01838f323cf89cfdef87042932aca44.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return updatec01838f323cf89cfdef87042932aca44.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
updatec01838f323cf89cfdef87042932aca44.patch = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatec01838f323cf89cfdef87042932aca44.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
    const updatec01838f323cf89cfdef87042932aca44Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatec01838f323cf89cfdef87042932aca44.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:137
 * @route '/tickets/{ticket}'
 */
        updatec01838f323cf89cfdef87042932aca44Form.patch = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatec01838f323cf89cfdef87042932aca44.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatec01838f323cf89cfdef87042932aca44.form = updatec01838f323cf89cfdef87042932aca44Form

export const update = {
    '/tickets/{ticket}': updatec01838f323cf89cfdef87042932aca44,
    '/tickets/{ticket}': updatec01838f323cf89cfdef87042932aca44,
}

/**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:163
 * @route '/tickets/{ticket}'
 */
export const destroy = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/tickets/{ticket}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:163
 * @route '/tickets/{ticket}'
 */
destroy.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return destroy.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:163
 * @route '/tickets/{ticket}'
 */
destroy.delete = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:163
 * @route '/tickets/{ticket}'
 */
    const destroyForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:163
 * @route '/tickets/{ticket}'
 */
        destroyForm.delete = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TicketController = { exportMethod, detail, timeline, downloadFile, addActivity, complete, revisit, scheduleVisit, index, create, store, show, edit, update, destroy, export: exportMethod }

export default TicketController