import DashboardController from './DashboardController'
import EngineerController from './EngineerController'
import SpecialPlaceController from './SpecialPlaceController'
import TicketController from './TicketController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
EngineerController: Object.assign(EngineerController, EngineerController),
SpecialPlaceController: Object.assign(SpecialPlaceController, SpecialPlaceController),
TicketController: Object.assign(TicketController, TicketController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers